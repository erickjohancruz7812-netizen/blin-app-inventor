#|
$JSON
{"authURL": ["ai2a.appinventor.mit.edu"], "YaVersion": "237", "Source": "Form", "Properties": {"$Name": "Screen12", "$Type": "Form", "$Version": "32", "ActionBar": "False", "AlignHorizontal": "3", "AlignVertical": "1", "AppName": "blin", "BackgroundColor": "&HFF020B24", "Scrollable": "False", "Title": "Navegador", "TitleVisible": "False", "Uuid": "0", "$Components": [{"$Name": "BotonVolverPagina", "$Type": "Button", "$Version": "8", "Text": "VOLVER", "FontSize": "18", "FontBold": "True", "BackgroundColor": "&HFF1565C0", "TextColor": "&HFFFFFFFF", "Width": "-2", "Uuid": "-1148788830"}, {"$Name": "VisorWeb", "$Type": "WebViewer", "$Version": "11", "Height": "-2", "Width": "-2", "FollowLinks": "True", "UsesLocation": "False", "Uuid": "1351884183"}]}}
|#
